package com.virtusa.service;

public class SimpleLoop {
	
	int array[]={5,-1,13,4,-2,6};
	
	public int findTotal(int n){
		
		int total=0;
		if(n>0){
			
			for(int count=0;count<n;count++){
				if(array[count]>0){
					total=total+array[count];
				}
				
			}		
		}
		return total;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SimpleLoop simpleLoop=new SimpleLoop();
		System.out.println(simpleLoop.findTotal(1));

	}

}
