package com.virtusa.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.virtusa.service.SimpleLoop;

public class TestSimpleLoop {
	
	private SimpleLoop simpleLoop=null;

	@Before
	public void setUp() throws Exception {
		simpleLoop=new SimpleLoop();
	}

	@After
	public void tearDown() throws Exception {
		simpleLoop=null;
	}

	@Test
	public void test_find_total_loopatleastOnce() {
		int n=1;
		//test data {5,-1,13,4,-2,6}
		int actual=simpleLoop.findTotal(n);
		int expected=5;
		assertEquals(actual,expected);
		
	}
	@Test
	public void test_find_total_loopignored(){
		int n=-1;
		//test data {5,-1,13,4,-2,6}
		int actual=simpleLoop.findTotal(n);
		int expected=0;
		assertEquals(actual,expected);
		
	}
	@Test
	public void test_final_total_moreThanOnce(){
		int n=3;
		int actual=simpleLoop.findTotal(n);
		int expected=18;
		assertEquals(actual,expected);
	}
	@Test
	public void test_final_total_lengthminusOne(){
		//test data {5,-1,13,4,-2,6}
		int n=5;
		int actual=simpleLoop.findTotal(n);
		int expected=22;
		assertEquals(actual,expected);
		
	}
	@Test
	public void test_final_total_lengthplusOne(){
		//test data {5,-1,13,4,-2,6}
		int n=7;
		try{
		int actual=simpleLoop.findTotal(n);
		assertTrue(false);
		}catch(ArrayIndexOutOfBoundsException e){
			assertTrue(true);
		}
		
		
	}

}
