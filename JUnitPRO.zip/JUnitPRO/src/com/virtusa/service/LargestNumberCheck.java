package com.virtusa.service;

public class LargestNumberCheck {
	
	 public int findLargest(int ... n){
		 
		 if(n.length>=20){
			 throw new RuntimeException("Array size exceeded");	 
		 }
		   int i;
		   int max=0; 
		   if(n.length==0){
			   return max;
		   }else{
			    max = n[0];
	       for (i = 1; i < n.length; i++){
	             if (n[i] > max){ 
	                 max = n[i];
	             }
	       }
		   }
	         return max; 
	     } 
		 
		 
	 }
	     
	       
	      
	       
	       
	    


