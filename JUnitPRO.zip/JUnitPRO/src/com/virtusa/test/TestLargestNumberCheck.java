package com.virtusa.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.virtusa.service.LargestNumberCheck;

public class TestLargestNumberCheck {
	
	private LargestNumberCheck largestNumberCheck=null;

	@Before
	public void setUp() throws Exception {
		largestNumberCheck=new LargestNumberCheck();
	}

	@After
	public void tearDown() throws Exception {
		largestNumberCheck=null;
	}

	@Test
	public void test_findLargest_positive() {
		
		//test data
		int n[]={34,1,23,67,56};
		
		int actual=largestNumberCheck.findLargest(n);
		int expected=67;
		assertEquals(expected,actual);
	}
	
	@Test
	public void test_findLargest_negative() {
		
		//test data
		int n[]={34,1,23,67,56,23,22,56,34,78,90,43,34,78,65,43,21,22,26,27,29};
		try{
		int actual=largestNumberCheck.findLargest(n);	
		assertTrue(false);
		}catch(RuntimeException e){
			assertTrue(true);
			
		}
	}
	@Test
	public void test_findLargest_emptyArray(){
		int n[]=new int[0];
		int actual=largestNumberCheck.findLargest(n);
		assertEquals(0,actual);
		
		
	}
	@Test
	public void test_findLargest_OneElementArray(){
		
		int n[]={1};
		int actual=largestNumberCheck.findLargest(n);
		int expected=1;
		assertEquals(expected,actual);
	}

}
